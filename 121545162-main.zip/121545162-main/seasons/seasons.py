from datetime import date

def main():

        t = input('birth date?')
        x = datetime.date.t
        print(x)
main()
