name = input("").replace(' ', '...')
print(name)

